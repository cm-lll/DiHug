# 结果收尾包

先读SUMMARY_ZH.md（一页汇报）、REPORT.md（分seed/分阶段对照），再读METRIC_DIRECTORY.md。
全部实际生成使用EMA0.99，不含raw新生成。48张原图+48派生LCC；IMDB无1000/2000图，未列为失败或用p0替代。
`tables/paired*`为同阶段数量项增量；`length*`为同一训练轨迹相邻阶段变化；`total_length_paired`明确3000→6000。raw数量差与absolute_error差分列。
`tables/validation*`为普通固定前向噪声状态的raw/EMA验证；`training*`为训练记录。它们与真实生成指标独立，不画成同一类曲线。
`saved_logs`保留原日志副本和原来的时间/错误；`evidence`保留原失败与旧审计。权重仅登记来源和SHA256，不在公开包夹带大型.pt。
本次只用CPU整理，训练/前向/生成新增均为0。未新增科学审批，无自动继续入口。
