# Current-base diffusion evidence

The diffusion ablation table is frozen from:

`results/diffusion_ablation_current_base_0729/paper_tables/sample_ablation.tsv`

It contains eight generation seeds for each IMDB and PubMed condition. The
full-graph DiHug rows are evaluated from the corresponding `main/final_graph.json`
files under the same results directory. `fullgraph_dihug_extended.tsv` records
the resulting global, degree-distribution, typed-triangle, typed-walk, and edge
overlap metrics from those same graphs.
