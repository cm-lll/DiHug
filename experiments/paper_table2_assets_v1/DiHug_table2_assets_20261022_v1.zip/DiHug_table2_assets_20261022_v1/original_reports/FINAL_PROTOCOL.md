# Frozen Paper Protocol

This repository is frozen to the target-free, GPU-resident role-guided edit
pipeline for the paper experiments. Historical HSD/GQER/controller experiment
configs have been removed from the active Hydra config search path so they
cannot be launched accidentally.

## Active method

- Initialization: independent family Binomial/Bernoulli prior.
- Denoising: learned role-guided relocation and typed switch edits.
- Optional frozen context residual: enabled per dataset only after a paired
  held-out utility/generation gate. The frozen paper setting enables it for
  PubMed and disables it for IMDB; it must not read clean adjacency or
  evaluation targets at sampling time.
- Context fusion is node-only: typed edges drive sparse message passing, while
  complete edit candidates are decoded from endpoint node states. The active
  method does not maintain hidden states for existing or NULL candidate edges.
- GPU path: resident graph state, streamed proposal pools, and fused Triton
  typed-closure scoring.
- Multi-sample path: independent same-schema chains can share one batched MLP
  and block-diagonal sparse-HGT forward. Candidate generation, RNG, selection,
  and mutation remain chain-local, so batching does not change the transition
  semantics. Use `scripts/run_batched_context_generation.py`.

The unconditional paper main protocol uses `FAMILY_COUNT_MODE=binomial`.
`FAMILY_COUNT_MODE=fixed` conditions on the clean family edge counts and is
reported only as a conditional upper-bound/ablation, never as the main result.

The strict reverse-time contract uses one normalized time interval over the
actual edit budget: `--steps 10000 --model-time-horizon-steps 10000`.
The earlier `10000/20000` setting is a truncated-time decoder ablation, not the
canonical complete-time protocol.  Both settings use the same exact terminal
sampler, checkpoint, guided candidate policy, and GPU transition kernel.

## Canonical entry points

- `scripts/run_strict_edit_diffusion_formal_16seed_8gpu.sh`
- `scripts/run_diffusion_paper_evidence_queue_8gpu.sh`
- `scripts/run_imdb_full_time_confirmation_16seed_8gpu.sh`
- `scripts/run_pubmed_full_time_confirmation_16seed_8gpu.sh`
- `scripts/run_paper_cross_dataset_binomial_8gpu.sh`
- `scripts/run_paper_final_evidence_8gpu.sh`
- `scripts/run_pubmed_hgen40_nested_selection_8gpu.sh`
- `scripts/run_rooted_context_freeze_2gpu.sh`
- `scripts/run_batched_context_generation.py`

`scripts/run_paper_final_context_main_8gpu.sh` is a pre-strict historical
launcher.  It relies on the reference CPU/legacy candidate defaults and its
outputs must not be used as the paper main result.  The paper-facing 16-seed
results use `--sampling-backend gpu --gpu-candidate-mode canonical_ordered`
explicitly and record both fields in every `gate_report.json`.

The complete-time 16-seed confirmations are stored under
`results/imdb_full_time_confirmation16_0725` and
`results/pubmed_full_time_confirmation16_0725`.  The paired proposal audit is
stored under `results/reverse_schedule_proposal_audit_0725`; it verifies that
removing role-targeted relocation and wedge-seeded switch proposals causes a
large quality collapse, so guided candidate construction remains part of the
active reverse decoder.

`scripts/run_dblp_role_completion_8gpu.sh` is a step-budget diagnostic only;
its 150k result is not the paper main protocol.

## Do not revive

Do not launch or recreate experiment configs for GQER, family-set ranking,
absorbing posterior, block-global posterior, learned limiter/controller,
two-hop/query-gate, closure-bucket, node-closure, population quota, or old HSD
sampling sweeps. Their historical implementations remain recoverable through
Git history, but they are not active paper methods.

The jointly unfrozen HGT + edit-MLP context experiment is also inactive. Its
strict paired gate did not improve closure and anonymous-role alignment
simultaneously on IMDB, PubMed, DBLP, and Syn-200. The temporary trainer and
launchers were removed after the gate; the experiment remains available in Git
history only.

## Reproducibility rule

Every paper run must record the Git commit, dataset fingerprint, checkpoint
hash, seed range, initialization mode, and whether clean adjacency or metric
targets are accessible during sampling. Independently trained checkpoints from
different machines are reported separately rather than merged into one mean.
