#!/usr/bin/env bash
set -euo pipefail

source "${CONDA_SH:-/data2/lyh/miniconda3/etc/profile.d/conda.sh}"
conda activate "${CONDA_ENV:-sparse_block}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1

OUT_ROOT="${OUT_ROOT:-results/strict_edit_diffusion_multiseed_0721}"
LOG_ROOT="${LOG_ROOT:-logs/strict_edit_diffusion_multiseed_0721}"
IMDB_MODEL="${IMDB_MODEL:-results/strict_edit_diffusion_gate_0721/imdb_strict_cal5/mixed_edit_diffusion.pt}"
PUBMED_MODEL="${PUBMED_MODEL:-results/strict_edit_diffusion_gate_0721/pubmed_strict_cal5/mixed_edit_diffusion.pt}"
IMDB_ROLE="${IMDB_ROLE:-results/paper_extended_metrics_main16_0719/imdb/seed0/legacy/exchangeable_role_degree_prior.json}"
PUBMED_ROLE="${PUBMED_ROLE:-results/paper_extended_metrics_main16_0719/pubmed/seed1/legacy/exchangeable_role_degree_prior.json}"
PUBMED_CONTEXT="${PUBMED_CONTEXT:-/data2/lyh/gnn_project/DiHug/results/rooted_context_freeze/pubmed/rooted_context_residual.pt}"
mkdir -p "$OUT_ROOT" "$LOG_ROOT"
SEED_START="${SEED_START:-0}"
SEED_END="${SEED_END:-3}"
MODEL_TIME_HORIZON_STEPS="${MODEL_TIME_HORIZON_STEPS:-10000}"
if (( SEED_END < SEED_START || SEED_END - SEED_START + 1 > 4 )); then
  echo "each 8-GPU batch must contain between one and four seeds" >&2
  exit 2
fi

for path in "$IMDB_MODEL" "$PUBMED_MODEL" "$IMDB_ROLE" "$PUBMED_ROLE" "$PUBMED_CONTEXT"; do
  [[ -f "$path" ]] || { echo "missing required artifact: $path" >&2; exit 2; }
done

run_one() {
  local gpu="$1" dataset="$2" seed="$3" data="$4" model="$5" role="$6"
  shift 6
  local out="$OUT_ROOT/$dataset/seed${seed}"
  local log="$LOG_ROOT/${dataset}_s${seed}.log"
  mkdir -p "$out"
  CUDA_VISIBLE_DEVICES="$gpu" python -u scripts/run_role_guided_replacement_gate.py \
    --dataset-dir "$data" --model-checkpoint "$model" --role-prior "$role" \
    --strict-target-free --family-count-mode binomial --seed "$seed" \
    --device cuda --sampling-backend gpu --gpu-candidate-mode canonical_ordered \
    --steps 10000 --metrics-every 1000 \
    --model-time-horizon-steps "$MODEL_TIME_HORIZON_STEPS" \
    --role-weight 0.05 --gain-scale 10 --schedule-power 1 --schedule-floor 1 \
    --role-error-per-node-threshold 5.5 --closure-candidate-fraction 1 \
    --auto-role-balance 0.5 --targeted-role-candidate-fraction 0.5 \
    "$@" --output-dir "$out" > "$log" 2>&1
}

pids=()
gpu_slot=0
for ((seed=SEED_START; seed<=SEED_END; seed++)); do
  run_one "$gpu_slot" imdb "$seed" data/IMDB_movie_subgraphs/subgraph_000 \
    "$IMDB_MODEL" "$IMDB_ROLE" --candidates 64 &
  pids+=("$!")
  run_one "$((gpu_slot + 4))" pubmed "$seed" data/PubMed_baseline_subgraphs/subgraph_000 \
    "$PUBMED_MODEL" "$PUBMED_ROLE" --candidates 16 \
    --context-checkpoint "$PUBMED_CONTEXT" --context-refresh-steps 20 &
  pids+=("$!")
  gpu_slot=$((gpu_slot + 1))
done

failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
[[ "$failed" -eq 0 ]] || { echo "strict diffusion multiseed gate failed" >&2; exit 1; }

python - "$OUT_ROOT" <<'PY'
import json
import pathlib
import statistics
import sys

root = pathlib.Path(sys.argv[1])
summary = {"format": "dihug-strict-edit-diffusion-multiseed-v1", "datasets": {}}
for dataset in ("imdb", "pubmed"):
    rows = []
    for path in sorted((root / dataset).glob("seed*/gate_report.json")):
        report = json.loads(path.read_text())
        rows.append({"seed": int(path.parent.name[4:]), **report["final"]})
    if not rows:
        raise RuntimeError(f"found no {dataset} rows")
    keys = ("edges", "triangles", "clustering", "assortativity", "sum_degree_sq", "max_degree", "lcc")
    summary["datasets"][dataset] = {
        "rows": rows,
        "mean": {key: statistics.fmean(row[key] for row in rows) for key in keys},
        "std": {key: statistics.pstdev(row[key] for row in rows) for key in keys},
    }
(root / "aggregate.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
print(json.dumps(summary, indent=2, sort_keys=True))
PY

echo "[STRICT-EDIT-DIFFUSION-MULTISEED] complete: $OUT_ROOT/aggregate.json"
