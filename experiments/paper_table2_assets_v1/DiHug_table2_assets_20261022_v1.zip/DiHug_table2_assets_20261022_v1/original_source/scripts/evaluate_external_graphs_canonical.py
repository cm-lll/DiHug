#!/usr/bin/env python3
"""Evaluate external simple graphs with DiHug's canonical global metrics."""

from __future__ import annotations

import argparse
import json
import math
import pickle
from pathlib import Path
from statistics import fmean, pstdev

import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components

from sparse_diffusion.structure_energy.graph import (
    FamilySpec,
    TypedGraph,
    load_typed_graph,
)
from sparse_diffusion.structure_energy.heterogeneous_metrics import (
    aggregate_comparisons,
    compare_heterogeneous_graphs,
    degree_mmd_report,
    powerlaw_tail_fit,
)
from sparse_diffusion.structure_energy.switch_chain import graph_metrics


def load_external(
    path: Path, num_nodes: int
) -> tuple[set[tuple[int, int]], np.ndarray | None]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if int(payload["num_nodes"]) != num_nodes:
        raise ValueError(
            f"{path}: node count {payload['num_nodes']} != canonical {num_nodes}"
        )
    edges: set[tuple[int, int]] = set()
    for raw_u, raw_v in payload["edges"]:
        u, v = int(raw_u), int(raw_v)
        if u == v:
            raise ValueError(f"{path}: self-loop {(u, v)}")
        if min(u, v) < 0 or max(u, v) >= num_nodes:
            raise ValueError(f"{path}: endpoint outside node inventory {(u, v)}")
        edge = (min(u, v), max(u, v))
        if edge in edges:
            raise ValueError(f"{path}: duplicate edge {edge}")
        edges.add(edge)
    raw_types = payload.get("node_types")
    node_types = None
    if raw_types is not None:
        node_types = np.asarray(raw_types, dtype=np.int64)
        if node_types.shape != (num_nodes,):
            raise ValueError(
                f"{path}: node_types shape {node_types.shape} != {(num_nodes,)}"
            )
    return edges, node_types


def load_hgen_reference(
    dataset_dir: Path,
) -> tuple[set[tuple[int, int]], np.ndarray]:
    """Reproduce HGEN's largest-component graph and node ordering."""
    with (dataset_dir / "new_node_dict.p").open("rb") as handle:
        node_dict = pickle.load(handle)
    with (dataset_dir / "adj_matrix.p").open("rb") as handle:
        adjacency = sp.csr_matrix(pickle.load(handle))
    adjacency = adjacency.copy()
    adjacency.data = np.ones_like(adjacency.data)
    adjacency.setdiag(0)
    adjacency.eliminate_zeros()
    adjacency = adjacency.maximum(adjacency.T)
    _, component = connected_components(adjacency)
    sizes = np.bincount(component)
    largest = int(np.argmax(sizes))
    lcc = np.flatnonzero(component == largest)
    adjacency = adjacency[lcc][:, lcc].tocoo()
    edges = {
        (min(int(u), int(v)), max(int(u), int(v)))
        for u, v in zip(adjacency.row, adjacency.col)
        if int(u) != int(v)
    }
    node_types = np.asarray(
        [int(node_dict[int(node)]) for node in lcc], dtype=np.int64
    )
    return edges, node_types


def simple_metrics(num_nodes: int, edges: set[tuple[int, int]]) -> dict[str, float]:
    adjacency = [set() for _ in range(num_nodes)]
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    degree = np.asarray([len(row) for row in adjacency], dtype=np.float64)

    triangles_per_node = np.zeros(num_nodes, dtype=np.int64)
    triangles = 0
    for u, v in edges:
        for w in adjacency[u] & adjacency[v]:
            if w > v:
                triangles += 1
                triangles_per_node[[u, v, w]] += 1
    denominator = degree * (degree - 1.0) / 2.0
    clustering = np.divide(
        triangles_per_node,
        denominator,
        out=np.zeros_like(degree),
        where=denominator > 0,
    )

    visited: set[int] = set()
    lcc = 0
    for start in range(num_nodes):
        if start in visited:
            continue
        stack = [start]
        visited.add(start)
        size = 0
        while stack:
            node = stack.pop()
            size += 1
            for neighbor in adjacency[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    stack.append(neighbor)
        lcc = max(lcc, size)

    left, right = [], []
    for u, v in edges:
        left.extend((degree[u], degree[v]))
        right.extend((degree[v], degree[u]))
    if len(left) < 2 or np.std(left) == 0.0 or np.std(right) == 0.0:
        assortativity = 0.0
    else:
        assortativity = float(np.corrcoef(left, right)[0, 1])
        if not math.isfinite(assortativity):
            assortativity = 0.0

    return {
        "edges": float(len(edges)),
        "lcc": float(lcc),
        "triangles": float(triangles),
        "clustering": float(clustering.mean()),
        "assortativity": assortativity,
        "sum_degree_sq": float(np.square(degree).sum()),
        "max_degree": float(degree.max(initial=0.0)),
    }


def type_pair_graph(
    node_types: np.ndarray,
    type_names: tuple[str, ...],
    edges: set[tuple[int, int]],
) -> TypedGraph:
    """Represent every unordered endpoint-type pair as a canonical family."""
    nodes_by_type = {
        type_id: tuple(np.flatnonzero(node_types == type_id).astype(int))
        for type_id in range(len(type_names))
    }
    family_specs = {}
    family_edges = {}
    for src_type in range(len(type_names)):
        for dst_type in range(src_type, len(type_names)):
            family = f"typepair:{src_type}:{dst_type}"
            family_specs[family] = FamilySpec(
                name=family,
                src_type=src_type,
                dst_type=dst_type,
                src_nodes=nodes_by_type[src_type],
                dst_nodes=nodes_by_type[dst_type],
            )
            family_edges[family] = []
    for u, v in edges:
        src_type, dst_type = sorted((int(node_types[u]), int(node_types[v])))
        family_edges[f"typepair:{src_type}:{dst_type}"].append((u, v))
    return TypedGraph(node_types, type_names, family_specs, family_edges)


def typed_external_graph(
    target: TypedGraph,
    edges: set[tuple[int, int]],
    node_types: np.ndarray,
) -> TypedGraph:
    return type_pair_graph(node_types, target.type_names, edges)


def population_std(payload: object, samples: int) -> object:
    """Convert aggregate_comparisons' sample std fields to population std."""
    if isinstance(payload, dict):
        output = {
            key: population_std(value, samples) for key, value in payload.items()
        }
        if "std" in output and isinstance(output["std"], (int, float)):
            output["std"] = float(output["std"]) * math.sqrt(
                max(samples - 1, 0) / max(samples, 1)
            )
        return output
    if isinstance(payload, list):
        return [population_std(value, samples) for value in payload]
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--generated", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--hgen-data-dir",
        type=Path,
        help="Recover HGEN's generated-node type ordering for legacy exports.",
    )
    args = parser.parse_args()

    target = load_typed_graph(args.dataset_dir, active_only=True)
    target_metrics = graph_metrics(target)
    target_degrees = target.degrees()
    allowed_type_pairs = {
        tuple(sorted((int(spec.src_type), int(spec.dst_type))))
        for spec in target.family_specs.values()
    }
    target_edges = set(target.edge_family)
    typed_target = type_pair_graph(
        target.node_types,
        target.type_names,
        target_edges,
    )
    rows = []
    typed_rows = []
    fingerprints = []
    hgen_reference_edges = None
    fallback_node_types = None
    if args.hgen_data_dir is not None:
        hgen_reference_edges, fallback_node_types = load_hgen_reference(
            args.hgen_data_dir
        )
    if fallback_node_types is not None and fallback_node_types.shape != (
        target.num_nodes,
    ):
        raise ValueError(
            "HGEN node inventory does not match canonical target: "
            f"{fallback_node_types.shape} != {(target.num_nodes,)}"
        )
    node_order_matches = (
        fallback_node_types is None
        or (
            np.array_equal(fallback_node_types, target.node_types)
            and hgen_reference_edges == target_edges
        )
    )
    for sample, path in enumerate(args.generated):
        edges, generated_node_types = load_external(path, target.num_nodes)
        if generated_node_types is None:
            generated_node_types = fallback_node_types
        if generated_node_types is not None:
            violations = [
                edge
                for edge in edges
                if tuple(
                    sorted(
                        (
                            int(generated_node_types[edge[0]]),
                            int(generated_node_types[edge[1]]),
                        )
                    )
                )
                not in allowed_type_pairs
            ]
            schema_valid_fraction = 1.0 - len(violations) / max(len(edges), 1)
        else:
            schema_valid_fraction = None
        metrics = simple_metrics(target.num_nodes, edges)
        generated_degrees = np.zeros(target.num_nodes, dtype=np.int64)
        for u, v in edges:
            generated_degrees[u] += 1
            generated_degrees[v] += 1
        metrics.update(degree_mmd_report(target_degrees, generated_degrees))
        metrics["powerlaw_alpha"] = powerlaw_tail_fit(generated_degrees)["alpha"]
        if node_order_matches:
            metrics["edge_overlap_percent"] = (
                100.0 * len(target_edges & edges) / max(len(target_edges), 1)
            )
        if schema_valid_fraction is not None:
            metrics["schema_valid_percent"] = 100.0 * schema_valid_fraction
        metrics["sample"] = sample
        metrics["source"] = str(path)
        rows.append(metrics)
        if generated_node_types is not None:
            typed_rows.append(
                compare_heterogeneous_graphs(
                    typed_target,
                    typed_external_graph(target, edges, generated_node_types),
                )
            )
        fingerprints.append(tuple(sorted(edges)))

    metric_names = (
        "edges",
        "lcc",
        "triangles",
        "clustering",
        "assortativity",
        "sum_degree_sq",
        "max_degree",
        "degree_mmd",
        "powerlaw_alpha",
    )
    if all("edge_overlap_percent" in row for row in rows):
        metric_names = (*metric_names, "edge_overlap_percent")
    if all("schema_valid_percent" in row for row in rows):
        metric_names = (*metric_names, "schema_valid_percent")
    report = {
        "format": "dihug-canonical-external-graph-evaluation-v1",
        "dataset_dir": str(args.dataset_dir.resolve()),
        "target": target_metrics,
        "target_powerlaw_alpha": powerlaw_tail_fit(target_degrees)["alpha"],
        "samples": len(rows),
        "rows": rows,
        "mean": {
            metric: fmean(float(row[metric]) for row in rows)
            for metric in metric_names
        },
        "std": {
            metric: pstdev(float(row[metric]) for row in rows)
            for metric in metric_names
        },
        "uniqueness_percent": (
            100.0 * len(set(fingerprints)) / max(len(fingerprints), 1)
        ),
    }
    if args.hgen_data_dir is not None:
        report["node_identity_alignment"] = {
            "comparable": bool(node_order_matches),
            "node_types_equal": bool(
                np.array_equal(fallback_node_types, target.node_types)
            ),
            "reference_edges_equal": bool(
                hgen_reference_edges == target_edges
            ),
            "reason": (
                "HGEN and canonical node orders describe the same reference "
                "edge set"
                if node_order_matches
                else "HGEN and canonical node orders differ; identity-level "
                "edge overlap is omitted"
            ),
        }
    if len(typed_rows) == len(rows):
        report["heterogeneous"] = population_std(
            aggregate_comparisons(typed_rows), len(typed_rows)
        )
        if not node_order_matches:
            report["heterogeneous"].pop("edge_identity_diagnostic", None)
            report["heterogeneous"]["edge_identity_omission"] = (
                "node orders differ, so identity-level edge overlap is omitted"
            )
    else:
        report["heterogeneous"] = None
        report["heterogeneous_omission"] = (
            "generated node types were not exported; typed metrics unavailable"
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        f"[CANONICAL-EXTERNAL-EVAL] samples={len(rows)} "
        f"output={args.output}",
        flush=True,
    )


if __name__ == "__main__":
    main()
