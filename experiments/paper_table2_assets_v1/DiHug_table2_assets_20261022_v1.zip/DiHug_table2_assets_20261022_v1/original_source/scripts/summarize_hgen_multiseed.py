#!/usr/bin/env python3
"""Validate and summarize independently seeded HGEN runs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


METRICS = (
    "lcc",
    "triangles",
    "clustering",
    "powerlaw",
    "assortativity",
    "degree_mmd",
    "edge_overlap_percent",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def close(left: float, right: float) -> bool:
    return math.isclose(float(left), float(right), rel_tol=1e-8, abs_tol=1e-10)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--hgen-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    rows = []
    target_fingerprints = {}
    for report_path in sorted(args.root.glob("*/seed*/report.json")):
        report = json.loads(report_path.read_text())
        seed_dir = report_path.parent
        seed = int(seed_dir.name.removeprefix("seed"))
        dataset = seed_dir.parent.name
        real = report["real"]
        generated = report["generated"]
        fingerprint = {
            key: float(real[key])
            for key in ("lcc", "triangles", "clustering", "powerlaw", "assortativity")
        }
        if dataset in target_fingerprints:
            if any(
                not close(fingerprint[key], target_fingerprints[dataset][key])
                for key in fingerprint
            ):
                raise RuntimeError(f"target fingerprint changed across {dataset} seeds")
        else:
            target_fingerprints[dataset] = fingerprint

        row = {
            "dataset": dataset,
            "seed": seed,
            **{key: float(generated[key]) for key in generated},
            "degree_mmd": float(report["degree_mmd"]),
            "edge_overlap_percent": float(report["edge_overlap_percent"]),
            "report_sha256": sha256(report_path),
            "log_sha256": sha256(seed_dir / "run.log"),
        }
        if not all(math.isfinite(float(row[key])) for key in METRICS):
            raise RuntimeError(f"non-finite HGEN metric in {report_path}")
        rows.append(row)

    if not rows:
        raise RuntimeError(f"no HGEN reports found under {args.root}")

    expected = {"imdb", "pubmed", "dblp"}
    observed = {row["dataset"] for row in rows}
    if observed != expected:
        raise RuntimeError(f"expected datasets {sorted(expected)}, got {sorted(observed)}")
    seed_sets = {
        dataset: sorted(row["seed"] for row in rows if row["dataset"] == dataset)
        for dataset in observed
    }
    if len({tuple(seeds) for seeds in seed_sets.values()}) != 1:
        raise RuntimeError(f"inconsistent seed sets: {seed_sets}")

    aggregates = []
    for dataset in sorted(observed):
        group = [row for row in rows if row["dataset"] == dataset]
        aggregate = {
            "dataset": dataset,
            "n": len(group),
            "seeds": [row["seed"] for row in group],
            "real": target_fingerprints[dataset],
        }
        for metric in METRICS:
            values = [float(row[metric]) for row in group]
            aggregate[f"{metric}_mean"] = statistics.fmean(values)
            aggregate[f"{metric}_std"] = (
                statistics.pstdev(values) if len(values) > 1 else 0.0
            )
        aggregates.append(aggregate)

    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "per_seed.tsv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    payload = {
        "format": "dihug-hgen-independent-training-multiseed-v1",
        "dihug_commit": args.commit,
        "hgen_source": str(args.hgen_source.resolve()),
        "hgen_source_sha256": sha256(args.hgen_source),
        "split_seed": 481516234,
        "test_share": 0.4,
        "seed_sets": seed_sets,
        "aggregates": aggregates,
        "rows": rows,
    }
    (args.output / "aggregate.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({"seed_sets": seed_sets, "aggregates": aggregates}, indent=2))


if __name__ == "__main__":
    main()
