#!/usr/bin/env python3
"""Build protocol-consistent eight-run paper tables from frozen artifacts."""

from __future__ import annotations

import csv
import copy
import json
import math
import re
from pathlib import Path
from statistics import fmean, pstdev
from typing import Any

from sparse_diffusion.structure_energy.heterogeneous_metrics import (
    aggregate_comparisons,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "paper" / "results_20260727"
SEEDS = tuple(range(8))

DIHUG = {
    "imdb": ROOT
    / "results/diffusion_ablation_current_base_0729/extended_structure/imdb_main.json",
    "pubmed": ROOT
    / "results/diffusion_ablation_current_base_0729/extended_structure/pubmed_main.json",
    "dblp": ROOT
    / "paper/results_20260727/dblp_extended/dblp_legacy.json",
}

CLASSIC = {
    ("imdb", "GraphRNN"): ROOT
    / "results/classic_baseline_real_followup/imdb_graphrnn/report.json",
    ("imdb", "NetGAN"): ROOT
    / "results/classic_baseline_extension/imdb_netgan/report.json",
    ("imdb", "VGAE"): ROOT
    / "results/classic_baseline_extension/imdb_vgae/report.json",
    ("pubmed", "GraphRNN"): ROOT
    / "results/classic_baseline_real_followup/pubmed_graphrnn/report.json",
    ("pubmed", "NetGAN"): ROOT
    / "results/classic_baseline_extension/pubmed_netgan/report.json",
    ("pubmed", "VGAE"): ROOT
    / "results/classic_baseline_extension/pubmed_vgae/report.json",
    ("dblp", "NetGAN"): ROOT
    / "results/classic_baseline_real_followup/dblp_netgan/report.json",
    ("dblp", "VGAE"): ROOT
    / "results/classic_baseline_real_followup/dblp_vgae/report.json",
}

HGEN_ROOT = ROOT / "results/hgen_fullgraph_multiseed_audit_0727"
HGEN = HGEN_ROOT / "aggregate.json"
HGEN_CANONICAL_ROOT = (
    ROOT / "results/hgen_fullgraph_eo_audit_0729"
    if (ROOT / "results/hgen_fullgraph_eo_audit_0729").exists()
    else ROOT / "results/hgen_fullgraph_canonical_8run_0727"
)

CORE_METRICS = (
    "edges",
    "lcc",
    "triangles",
    "clustering",
    "assortativity",
)


def load(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def write_tsv(path: Path, rows: list[dict[str, Any]]) -> None:
    columns: list[str] = []
    for row in rows:
        columns.extend(key for key in row if key not in columns)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def convert_to_population_std(aggregate: dict[str, Any]) -> dict[str, Any]:
    """Convert aggregate_comparisons' sample std fields to population std."""

    output = copy.deepcopy(aggregate)
    samples = int(output["samples"])
    factor = math.sqrt((samples - 1) / samples) if samples > 1 else 0.0

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            if (
                set(("mean", "std")).issubset(value)
                and isinstance(value["std"], (int, float))
            ):
                value["std"] = float(value["std"]) * factor
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(output)
    return output


def selected_dihug(dataset: str) -> dict[str, Any]:
    payload = load(DIHUG[dataset])
    rows = [row for row in payload["rows"] if int(row["seed"]) in SEEDS]
    observed = tuple(sorted(int(row["seed"]) for row in rows))
    if observed != SEEDS:
        raise RuntimeError(f"{dataset}: expected seeds {SEEDS}, found {observed}")
    return convert_to_population_std(aggregate_comparisons(rows))


def core_from_comparison(
    dataset: str, method: str, aggregate: dict[str, Any]
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "dataset": dataset,
        "method": method,
        "n": int(aggregate["samples"]),
    }
    for metric in CORE_METRICS:
        generated = aggregate["global"][metric]["generated"]
        row[f"{metric}_mean"] = generated["mean"]
        row[f"{metric}_std"] = generated["std"]
        row[f"{metric}_target"] = aggregate["global"][metric]["target"]
    return row


def extended_from_comparison(
    dataset: str, method: str, aggregate: dict[str, Any]
) -> dict[str, Any]:
    edge_diag = aggregate["edge_identity_diagnostic"]
    powerlaw = aggregate["powerlaw"]
    row = {
        "dataset": dataset,
        "method": method,
        "n": int(aggregate["samples"]),
        "degree_mmd_mean": aggregate["degree_mmd"]["mean"],
        "degree_mmd_std": aggregate["degree_mmd"]["std"],
        "powerlaw_target_alpha": powerlaw["target"]["alpha"],
        "powerlaw_generated_alpha_mean": powerlaw["generated_alpha"]["mean"],
        "powerlaw_generated_alpha_std": powerlaw["generated_alpha"]["std"],
        "typed_triangle_tv_mean": aggregate["typed_triangles"]["tv"]["mean"],
        "typed_triangle_tv_std": aggregate["typed_triangles"]["tv"]["std"],
        "metapath_l1_tv_mean": aggregate["typed_metapaths"]["1"]["tv"]["mean"],
        "metapath_l1_tv_std": aggregate["typed_metapaths"]["1"]["tv"]["std"],
        "metapath_l2_tv_mean": aggregate["typed_metapaths"]["2"]["tv"]["mean"],
        "metapath_l2_tv_std": aggregate["typed_metapaths"]["2"]["tv"]["std"],
        "metapath_l3_tv_mean": aggregate["typed_metapaths"]["3"]["tv"]["mean"],
        "metapath_l3_tv_std": aggregate["typed_metapaths"]["3"]["tv"]["std"],
        "edge_overlap_percent_mean": edge_diag["edge_overlap_percent"]["mean"],
        "edge_overlap_percent_std": edge_diag["edge_overlap_percent"]["std"],
        "uniqueness_percent": aggregate["uniqueness_percent"],
        "schema_valid_percent_mean": 100.0,
        "schema_valid_percent_std": 0.0,
    }
    if "relation_degree_error" in aggregate:
        row["relation_degree_error_mean"] = aggregate["relation_degree_error"]["mean"]
        row["relation_degree_error_std"] = aggregate["relation_degree_error"]["std"]
    return row


def hgen_edges(dataset: str) -> tuple[float, float]:
    values = []
    for seed in SEEDS:
        path = HGEN_ROOT / dataset / f"seed{seed}" / "run.log"
        section = path.read_text(errors="replace").split(
            "========== Full Graph Evaluation"
        )[-1]
        counts = [
            int(value.replace(",", ""))
            for value in re.findall(r"Number of edges:\s*([0-9,]+)", section)
        ]
        if len(counts) < 2:
            raise RuntimeError(f"could not parse HGEN edge count from {path}")
        values.append(float(counts[1]))
    return fmean(values), pstdev(values)


def hgen_rows() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    payload = load(HGEN)
    aggregates = {row["dataset"]: row for row in payload["aggregates"]}
    core_rows = []
    extended_rows = []
    for dataset in ("imdb", "pubmed", "dblp"):
        source = aggregates[dataset]
        if tuple(source["seeds"]) != SEEDS or int(source["n"]) != len(SEEDS):
            raise RuntimeError(f"unexpected HGEN seeds for {dataset}")
        canonical_path = HGEN_CANONICAL_ROOT / dataset / "canonical_report.json"
        if not canonical_path.exists():
            canonical_path = HGEN_CANONICAL_ROOT / f"{dataset}.json"
        canonical = load(canonical_path) if canonical_path.exists() else None
        if canonical is not None:
            if int(canonical["samples"]) != len(SEEDS):
                raise RuntimeError(f"unexpected canonical HGEN samples: {canonical_path}")
            core_mean = canonical["mean"]
            core_std = canonical["std"]
            core_target = canonical["target"]
            edge_mean, edge_std = core_mean["edges"], core_std["edges"]
        else:
            edge_mean, edge_std = hgen_edges(dataset)
            core_mean = {
                "lcc": source["lcc_mean"],
                "triangles": source["triangles_mean"],
                "clustering": source["clustering_mean"],
            }
            core_std = {
                "lcc": source["lcc_std"],
                "triangles": source["triangles_std"],
                "clustering": source["clustering_std"],
            }
            core_target = {
                "lcc": source["real"]["lcc"],
                "triangles": source["real"]["triangles"],
                "clustering": source["real"]["clustering"],
            }
        core_rows.append(
            {
                "dataset": dataset,
                "method": "HGEN",
                "n": source["n"],
                "edges_mean": edge_mean,
                "edges_std": edge_std,
                "edges_target": None,
                "lcc_mean": core_mean["lcc"],
                "lcc_std": core_std["lcc"],
                "lcc_target": core_target["lcc"],
                "triangles_mean": core_mean["triangles"],
                "triangles_std": core_std["triangles"],
                "triangles_target": core_target["triangles"],
                "clustering_mean": core_mean["clustering"],
                "clustering_std": core_std["clustering"],
                "clustering_target": core_target["clustering"],
                "assortativity_mean": (
                    core_mean["assortativity"] if canonical is not None else None
                ),
                "assortativity_std": (
                    core_std["assortativity"] if canonical is not None else None
                ),
                "assortativity_target": (
                    core_target["assortativity"] if canonical is not None else None
                ),
            }
        )
        heterogeneous = canonical.get("heterogeneous") if canonical else None
        typed_paths = (
            heterogeneous["typed_metapaths"] if heterogeneous is not None else {}
        )
        extended_rows.append(
            {
                "dataset": dataset,
                "method": "HGEN",
                "n": source["n"],
                "degree_mmd_mean": (
                    canonical["mean"]["degree_mmd"]
                    if canonical is not None
                    else None
                ),
                "degree_mmd_std": (
                    canonical["std"]["degree_mmd"]
                    if canonical is not None
                    else None
                ),
                "powerlaw_target_alpha": (
                    canonical["target_powerlaw_alpha"]
                    if canonical is not None
                    else None
                ),
                "powerlaw_generated_alpha_mean": (
                    canonical["mean"]["powerlaw_alpha"]
                    if canonical is not None
                    else None
                ),
                "powerlaw_generated_alpha_std": (
                    canonical["std"]["powerlaw_alpha"]
                    if canonical is not None
                    else None
                ),
                "typed_triangle_tv_mean": (
                    heterogeneous["typed_triangles"]["tv"]["mean"]
                    if heterogeneous is not None
                    else None
                ),
                "typed_triangle_tv_std": (
                    heterogeneous["typed_triangles"]["tv"]["std"]
                    if heterogeneous is not None
                    else None
                ),
                "metapath_l1_tv_mean": (
                    typed_paths["1"]["tv"]["mean"] if typed_paths else None
                ),
                "metapath_l1_tv_std": (
                    typed_paths["1"]["tv"]["std"] if typed_paths else None
                ),
                "metapath_l2_tv_mean": (
                    typed_paths["2"]["tv"]["mean"] if typed_paths else None
                ),
                "metapath_l2_tv_std": (
                    typed_paths["2"]["tv"]["std"] if typed_paths else None
                ),
                "metapath_l3_tv_mean": (
                    typed_paths["3"]["tv"]["mean"] if typed_paths else None
                ),
                "metapath_l3_tv_std": (
                    typed_paths["3"]["tv"]["std"] if typed_paths else None
                ),
                "edge_overlap_percent_mean": (
                    canonical["mean"].get("edge_overlap_percent")
                    if canonical is not None
                    and canonical.get("node_identity_alignment", {}).get(
                        "comparable", False
                    )
                    else None
                ),
                "edge_overlap_percent_std": (
                    canonical["std"].get("edge_overlap_percent")
                    if canonical is not None
                    and canonical.get("node_identity_alignment", {}).get(
                        "comparable", False
                    )
                    else None
                ),
                "uniqueness_percent": (
                    canonical["uniqueness_percent"]
                    if canonical is not None
                    else None
                ),
                "schema_valid_percent_mean": (
                    canonical["mean"].get("schema_valid_percent")
                    if canonical is not None
                    else None
                ),
                "schema_valid_percent_std": (
                    canonical["std"].get("schema_valid_percent")
                    if canonical is not None
                    else None
                ),
            }
        )
    return core_rows, extended_rows


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    core_rows: list[dict[str, Any]] = []
    extended_rows: list[dict[str, Any]] = []

    for dataset in ("imdb", "pubmed", "dblp"):
        aggregate = selected_dihug(dataset)
        core_rows.append(core_from_comparison(dataset, "DiHug", aggregate))
        extended_rows.append(
            extended_from_comparison(dataset, "DiHug", aggregate)
        )

    for (dataset, method), path in CLASSIC.items():
        aggregate = convert_to_population_std(load(path)["aggregate"])
        if int(aggregate["samples"]) != len(SEEDS):
            raise RuntimeError(f"{path}: expected eight samples")
        core_rows.append(core_from_comparison(dataset, method, aggregate))
        extended_rows.append(
            extended_from_comparison(dataset, method, aggregate)
        )

    hgen_core, hgen_extended = hgen_rows()
    core_rows.extend(hgen_core)
    extended_rows.extend(hgen_extended)

    order = {"GraphRNN": 0, "NetGAN": 1, "VGAE": 2, "HGEN": 3, "DiHug": 4}
    core_rows.sort(key=lambda row: (row["dataset"], order[row["method"]]))
    extended_rows.sort(key=lambda row: (row["dataset"], order[row["method"]]))
    write_tsv(OUTPUT / "fullgraph_core_8run.tsv", core_rows)
    write_tsv(OUTPUT / "fullgraph_distribution_8run.tsv", extended_rows)

    provenance = {
        "format": "dihug-consistent-eight-run-paper-evidence-v1",
        "seeds": list(SEEDS),
        "population_standard_deviation": True,
        "dihug_sources": {key: str(value) for key, value in DIHUG.items()},
        "classic_sources": {
            f"{dataset}/{method}": str(path)
            for (dataset, method), path in CLASSIC.items()
        },
        "hgen_source": str(HGEN),
        "hgen_canonical_source": str(HGEN_CANONICAL_ROOT),
        "notes": [
            "DiHug rows use completed seeds 0--7 under the frozen current-base protocol.",
            "No run is selected by test performance.",
            "HGEN canonical metrics are populated only when generated node types are available or recovered from the released preprocessing.",
            "All HGEN global and typed metrics are recomputed from exported graphs by the canonical evaluator.",
        ],
    }
    (OUTPUT / "provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n", encoding="utf-8"
    )
    print(f"wrote consistent evidence to {OUTPUT}")


if __name__ == "__main__":
    main()
