#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/data2/lyh/gnn_project/DiHug_clean_joint}"
DATA_ROOT="${DATA_ROOT:-/data2/lyh/gnn_project/DiHug/data}"
OUT_ROOT="${OUT_ROOT:-$ROOT/results/classic_baseline_real_followup}"
LOG_ROOT="${LOG_ROOT:-$ROOT/logs/classic_baseline_real_followup}"
GPU_LIST=(${GPU_LIST:-4 5 6 7})
mkdir -p "$OUT_ROOT" "$LOG_ROOT"

run_job() {
  local gpu="$1" dataset="$2" method="$3" path="$4"
  local name="${dataset}_${method}"
  local max_prev=512
  if [[ "$method" == graphrnn && ("$dataset" == imdb || "$dataset" == pubmed) ]]; then
    # These graphs are below the 10k-node exclusion used by HGEN. Use the full
    # autoregressive horizon so node ordering does not silently remove edges.
    max_prev=4096
  fi
  local extra=(--epochs 300 --samples 8 --hidden 128 --latent 32 --max-prev-node "$max_prev")
  if [[ "$method" == netgan ]]; then
    extra=(--iterations 2000 --walk-samples 50000 --batch-size 64 --samples 8)
  fi
  CUDA_VISIBLE_DEVICES="$gpu" PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    python -u "$ROOT/scripts/run_classic_heterogeneous_baseline.py" \
      --method "$method" --dataset-dir "$path" \
      --output-dir "$OUT_ROOT/$name" --device cuda:0 --seed 0 \
      "${extra[@]}" > "$LOG_ROOT/$name.log" 2>&1
}

DBLP="$DATA_ROOT/DBLP_four_area_subgraphs/subgraph_000"
PUBMED="$DATA_ROOT/PubMed_baseline_subgraphs/subgraph_000"
IMDB="$DATA_ROOT/IMDB_movie_subgraphs/subgraph_000"
if [[ "${#GPU_LIST[@]}" -ge 4 ]]; then
  run_job "${GPU_LIST[0]}" pubmed graphrnn "$PUBMED" & p0=$!
  run_job "${GPU_LIST[1]}" dblp vgae "$DBLP" & p1=$!
  run_job "${GPU_LIST[2]}" imdb graphrnn "$IMDB" & p2=$!
  run_job "${GPU_LIST[3]}" dblp netgan "$DBLP" & p3=$!
  pids=("$p0" "$p1" "$p2" "$p3")
else
  # Two-lane mode avoids concurrent models sharing one GPU.
  (run_job "${GPU_LIST[0]}" pubmed graphrnn "$PUBMED" &&
   run_job "${GPU_LIST[0]}" dblp vgae "$DBLP") & p0=$!
  (run_job "${GPU_LIST[1]}" imdb graphrnn "$IMDB" &&
   run_job "${GPU_LIST[1]}" dblp netgan "$DBLP") & p1=$!
  pids=("$p0" "$p1")
fi
failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
[[ "$failed" -eq 0 ]] || exit 1
python "$ROOT/scripts/summarize_classic_baselines.py" \
  --input-root "$OUT_ROOT" --output-root "$OUT_ROOT"
