#!/usr/bin/env bash
# Eight independently seeded HGEN full-graph runs for IMDB, PubMed, and DBLP.
set -euo pipefail

source "${CONDA_SH:-/data2/lyh/miniconda3/etc/profile.d/conda.sh}"
conda activate "${CONDA_ENV:-sparse_block}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-2}"

HGEN_ROOT="${HGEN_ROOT:-/data2/lyh/gnn_project/HGEN}"
HGEN_PYTHON="${HGEN_PYTHON:-/data2/lyh/miniconda3/envs/hgen_env/bin/python}"
HGEN_EPOCHS="${HGEN_EPOCHS:-5}"
RUN_SEEDS="${RUN_SEEDS:-0 1 2 3 4 5 6 7}"
GPU_LIST="${GPU_LIST:-0 1 2 3 4 5 6 7}"
OUT_ROOT="${OUT_ROOT:-results/hgen_fullgraph_multiseed_audit_0727}"
LOG_ROOT="${LOG_ROOT:-logs/hgen_fullgraph_multiseed_audit_0727}"
read -r -a GPUS <<< "$GPU_LIST"
read -r -a SEEDS <<< "$RUN_SEEDS"

[[ "${#GPUS[@]}" -ge "${#SEEDS[@]}" ]] || {
  echo "GPU_LIST must provide one GPU per seed" >&2
  exit 2
}
[[ -x "$HGEN_PYTHON" ]] || { echo "missing HGEN Python: $HGEN_PYTHON" >&2; exit 2; }
[[ -f "$HGEN_ROOT/hgen.py" ]] || { echo "missing HGEN source" >&2; exit 2; }
mkdir -p "$OUT_ROOT" "$LOG_ROOT"

run_seed() {
  local gpu="$1" seed="$2"
  local dataset hgen_dataset out log
  for spec in "imdb:IMDB_movie" "pubmed:PubMed" "dblp:DBLP_four_area"; do
    dataset="${spec%%:*}"
    hgen_dataset="${spec#*:}"
    out="$OUT_ROOT/$dataset/seed${seed}"
    log="$LOG_ROOT/${dataset}_seed${seed}.log"
    if [[ -s "$out/report.json" && -s "$out/run.log" &&
          -s "$out/generated_graph.json" ]]; then
      echo "[HGEN-FULL-SKIP] dataset=$dataset seed=$seed" |
        tee -a "$LOG_ROOT/driver.log"
      continue
    fi
    mkdir -p "$out"
    echo "[HGEN-FULL-START] dataset=$dataset seed=$seed gpu=$gpu" |
      tee -a "$LOG_ROOT/driver.log"
    (
      cd "$HGEN_ROOT"
      PYTHONHASHSEED="$seed" CUDA_VISIBLE_DEVICES="$gpu" \
        "$HGEN_PYTHON" -u "$ROOT_DIR/scripts/run_seeded_hgen.py" \
        --source "$HGEN_ROOT/hgen.py" --run-seed "$seed" \
        --export-generated "$ROOT_DIR/$out/generated_graph.json" -- \
        --dataset "$hgen_dataset" --n-epochs "$HGEN_EPOCHS" \
        --eval-full-graph --skip-split-eval
    ) > "$log" 2>&1
    cp "$log" "$out/run.log"
    "$HGEN_PYTHON" "$ROOT_DIR/scripts/parse_hgen_baseline_log.py" \
      --log "$out/run.log" --dataset "$dataset" --output "$out/report.json"
    echo "[HGEN-FULL-DONE] dataset=$dataset seed=$seed gpu=$gpu" |
      tee -a "$LOG_ROOT/driver.log"
  done
}

pids=()
for index in "${!SEEDS[@]}"; do
  run_seed "${GPUS[$index]}" "${SEEDS[$index]}" &
  pids+=("$!")
  sleep 10
done
failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
[[ "$failed" -eq 0 ]] || { echo "one or more HGEN full-graph workers failed" >&2; exit 1; }

python scripts/summarize_hgen_multiseed.py \
  --root "$OUT_ROOT" \
  --commit "$(git rev-parse HEAD)" \
  --hgen-source "$HGEN_ROOT/hgen.py" \
  --output "$OUT_ROOT"

declare -A DATA_DIRS=(
  [imdb]="data/IMDB_movie_subgraphs/subgraph_000"
  [pubmed]="data/PubMed_baseline_subgraphs/subgraph_000"
  [dblp]="data/DBLP_four_area_subgraphs/subgraph_000"
)
declare -A HGEN_DATA_DIRS=(
  [imdb]="$HGEN_ROOT/IMDB_movie"
  [pubmed]="$HGEN_ROOT/PubMed"
  [dblp]="$HGEN_ROOT/DBLP_four_area"
)
for dataset in imdb pubmed dblp; do
  generated=()
  for seed in "${SEEDS[@]}"; do
    generated+=("$OUT_ROOT/$dataset/seed${seed}/generated_graph.json")
  done
  python scripts/evaluate_external_graphs_canonical.py \
    --dataset-dir "${DATA_DIRS[$dataset]}" \
    --hgen-data-dir "${HGEN_DATA_DIRS[$dataset]}" \
    --generated "${generated[@]}" \
    --output "$OUT_ROOT/$dataset/canonical_report.json"
done
echo "[HGEN-FULL-MULTISEED] complete: $OUT_ROOT/aggregate.json"
