#!/usr/bin/env python3
"""Run the released HGEN entry point with auditable random seeds.

The released script fixes the data-split seed but leaves training, sampling,
and one NumPy Generator seeded from system entropy. This wrapper changes only
those random sources; all HGEN arguments and model code remain untouched.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import runpy
import sys
from pathlib import Path

import numpy as np
import torch


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--run-seed", type=int, required=True)
    parser.add_argument(
        "--export-generated",
        type=Path,
        help="Export the generated full graph as a canonical simple edge list.",
    )
    parser.add_argument("hgen_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    source = args.source.resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    forwarded = list(args.hgen_args)
    if forwarded and forwarded[0] == "--":
        forwarded = forwarded[1:]

    seed = int(args.run_seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True

    # HGEN constructs one Generator(PCG64()) without a seed. Route only that
    # omitted seed to run_seed while preserving explicitly seeded calls.
    original_pcg64 = np.random.PCG64

    def seeded_pcg64(value=None):
        return original_pcg64(seed if value is None else value)

    np.random.PCG64 = seeded_pcg64
    sys.path.insert(0, str(source.parent))
    sys.argv = [str(source), *forwarded]
    print(
        "[HGEN-SEED-AUDIT] "
        f"run_seed={seed} source={source} sha256={sha256(source)} "
        f"argv={forwarded}",
        flush=True,
    )
    namespace = runpy.run_path(str(source), run_name="__main__")
    if args.export_generated is not None:
        generated = namespace.get("syn_graph_full")
        if generated is None:
            generated = namespace.get("syn_graph")
        if generated is None:
            raise RuntimeError("HGEN did not expose a generated graph")
        if hasattr(generated, "tocoo"):
            coo = generated.tocoo()
            num_nodes = int(generated.shape[0])
            edges = {
                (min(int(u), int(v)), max(int(u), int(v)))
                for u, v, value in zip(coo.row, coo.col, coo.data)
                if int(u) != int(v) and float(value) != 0.0
            }
        else:
            array = np.asarray(generated)
            num_nodes = int(array.shape[0])
            rows, columns = np.nonzero(array)
            edges = {
                (min(int(u), int(v)), max(int(u), int(v)))
                for u, v in zip(rows, columns)
                if int(u) != int(v)
            }
        raw_node_types = namespace.get("_X_obs")
        node_types = None
        if isinstance(raw_node_types, dict):
            node_types = [
                int(raw_node_types[index]) for index in range(num_nodes)
            ]
        payload = {
            "format": "dihug-external-simple-graph-v1",
            "source": "HGEN",
            "run_seed": seed,
            "num_nodes": num_nodes,
            "edges": [list(edge) for edge in sorted(edges)],
        }
        if node_types is not None:
            payload["node_types"] = node_types
        output = args.export_generated.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(payload, indent=2) + "\n", encoding="utf-8"
        )
        print(
            f"[HGEN-GRAPH-EXPORT] nodes={num_nodes} edges={len(edges)} "
            f"output={output}",
            flush=True,
        )


if __name__ == "__main__":
    main()
