#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/data2/lyh/gnn_project/DiHug_clean_joint}"
DATA_ROOT="${DATA_ROOT:-/data2/lyh/gnn_project/DiHug/data}"
OUT_ROOT="${OUT_ROOT:-$ROOT/results/classic_baseline_extension}"
LOG_ROOT="${LOG_ROOT:-$ROOT/logs/classic_baseline_extension}"
GPU_LIST=(${GPU_LIST:-0 1 2 3 4 5 6 7})
mkdir -p "$OUT_ROOT" "$LOG_ROOT"

# GraphVAE is intentionally absent here: its dense legal-edge vector is only
# practical on Syn100/200. The small-graph launcher runs its target-free prior.
jobs=(
  "syn500 vgae"
  "syn500 netgan"
  "syn500 graphrnn"
  "imdb vgae"
  "imdb netgan"
  "imdb graphrnn"
  "pubmed vgae"
  "pubmed netgan"
)

declare -A datasets=(
  [syn500]="$DATA_ROOT/HGEN_syn_500_subgraphs/subgraph_000"
  [imdb]="$DATA_ROOT/IMDB_movie_subgraphs/subgraph_000"
  [pubmed]="$DATA_ROOT/PubMed_baseline_subgraphs/subgraph_000"
)

[[ "${#GPU_LIST[@]}" -ge "${#jobs[@]}" ]] || {
  echo "Need ${#jobs[@]} GPUs, got ${#GPU_LIST[@]}" >&2
  exit 2
}
for dataset in "${datasets[@]}"; do
  [[ -f "$dataset/nodes.pt" && -f "$dataset/edges.pt" ]] || {
    echo "Missing dataset artifacts under $dataset" >&2
    exit 2
  }
done

pids=()
for index in "${!jobs[@]}"; do
  read -r dataset method <<<"${jobs[$index]}"
  gpu="${GPU_LIST[$index]}"
  name="${dataset}_${method}"
  extra=(--epochs 300 --samples 8 --hidden 128 --latent 32 --max-prev-node 512)
  if [[ "$method" == netgan ]]; then
    extra=(--iterations 2000 --walk-samples 50000 --batch-size 64 --samples 8)
  fi
  echo "[BASELINE-START] $name GPU=$gpu"
  CUDA_VISIBLE_DEVICES="$gpu" PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    python -u "$ROOT/scripts/run_classic_heterogeneous_baseline.py" \
      --method "$method" --dataset-dir "${datasets[$dataset]}" \
      --output-dir "$OUT_ROOT/$name" --device cuda:0 --seed 0 \
      "${extra[@]}" > "$LOG_ROOT/$name.log" 2>&1 &
  pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
  wait "$pid" || failed=1
done
[[ "$failed" -eq 0 ]] || {
  echo "At least one baseline failed; inspect $LOG_ROOT" >&2
  exit 1
}

python "$ROOT/scripts/summarize_classic_baselines.py" \
  --input-root "$OUT_ROOT" --output-root "$OUT_ROOT"
