#!/usr/bin/env bash
# Paired budget and time-conditioning ablations under the current base sampler.
set -euo pipefail

source "${CONDA_SH:-/data2/lyh/miniconda3/etc/profile.d/conda.sh}"
conda activate "${CONDA_ENV:-sparse_block}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-2}"

OUT_ROOT="${OUT_ROOT:-results/diffusion_ablation_current_base_0729}"
LOG_ROOT="${LOG_ROOT:-logs/diffusion_ablation_current_base_0729}"
GPU_LIST="${GPU_LIST:-0 1 2 3 4 5 6 7}"
SEEDS="${SEEDS:-0 1 2 3}"
IMDB_MODEL="${IMDB_MODEL:-results/strict_edit_diffusion_gate_0721/imdb_strict_cal5/mixed_edit_diffusion.pt}"
PUBMED_MODEL="${PUBMED_MODEL:-results/strict_edit_diffusion_gate_0721/pubmed_strict_cal5/mixed_edit_diffusion.pt}"
IMDB_ROLE="${IMDB_ROLE:-results/paper_extended_metrics_main16_0719/imdb/seed0/legacy/exchangeable_role_degree_prior.json}"
PUBMED_ROLE="${PUBMED_ROLE:-results/paper_extended_metrics_main16_0719/pubmed/seed1/legacy/exchangeable_role_degree_prior.json}"
IMDB_DATA="${IMDB_DATA:-data/IMDB_movie_subgraphs/subgraph_000}"
PUBMED_DATA="${PUBMED_DATA:-data/PubMed_baseline_subgraphs/subgraph_000}"
read -r -a GPUS <<< "$GPU_LIST"
read -r -a RUN_SEEDS <<< "$SEEDS"

[[ "${#GPUS[@]}" -eq 8 ]] || { echo "GPU_LIST must contain eight GPUs" >&2; exit 2; }
[[ "${#RUN_SEEDS[@]}" -eq 4 ]] || { echo "SEEDS must contain four seeds" >&2; exit 2; }
for path in "$IMDB_MODEL" "$PUBMED_MODEL" "$IMDB_ROLE" "$PUBMED_ROLE" \
  "$IMDB_DATA" "$PUBMED_DATA"; do
  [[ -e "$path" ]] || { echo "missing required input: $path" >&2; exit 2; }
done
mkdir -p "$OUT_ROOT/artifacts" "$OUT_ROOT/paper_tables" "$LOG_ROOT"

IMDB_NO_TIME="$OUT_ROOT/artifacts/imdb_no_time.pt"
PUBMED_NO_TIME="$OUT_ROOT/artifacts/pubmed_no_time.pt"
python scripts/build_time_ablated_checkpoint.py \
  --input "$IMDB_MODEL" --output "$IMDB_NO_TIME"
python scripts/build_time_ablated_checkpoint.py \
  --input "$PUBMED_MODEL" --output "$PUBMED_NO_TIME"

run_sample() {
  local gpu="$1" dataset="$2" seed="$3" mode="$4" steps="$5"
  local data model role candidates
  if [[ "$dataset" == "imdb" ]]; then
    data="$IMDB_DATA"; role="$IMDB_ROLE"; candidates=64
    [[ "$mode" == "time_no_condition" ]] && model="$IMDB_NO_TIME" || model="$IMDB_MODEL"
  else
    data="$PUBMED_DATA"; role="$PUBMED_ROLE"; candidates=16
    [[ "$mode" == "time_no_condition" ]] && model="$PUBMED_NO_TIME" || model="$PUBMED_MODEL"
  fi
  local out="$OUT_ROOT/$dataset/seed${seed}/$mode"
  local log="$LOG_ROOT/${dataset}_seed${seed}_${mode}.log"
  if [[ -s "$out/gate_report.json" ]]; then
    echo "[SKIP] dataset=$dataset seed=$seed mode=$mode"
    return
  fi
  mkdir -p "$out"
  CUDA_VISIBLE_DEVICES="$gpu" python -u scripts/run_role_guided_replacement_gate.py \
    --dataset-dir "$data" --model-checkpoint "$model" --role-prior "$role" \
    --strict-target-free --family-count-mode binomial --seed "$seed" \
    --device cuda --sampling-backend gpu --gpu-candidate-mode canonical_ordered \
    --steps "$steps" --model-time-horizon-steps "$steps" \
    --metrics-every "$steps" --candidates "$candidates" \
    --role-weight 0.05 --gain-scale 10 --schedule-power 1 --schedule-floor 1 \
    --role-error-per-node-threshold 5.5 --closure-candidate-fraction 1 \
    --auto-role-balance 0.5 --targeted-role-candidate-fraction 0.5 \
    --phase-policy auto --selection-mode model --context-scale 0 --decoder map \
    --output-dir "$out" > "$log" 2>&1
}

run_worker() {
  local gpu="$1" dataset="$2" seed="$3"
  run_sample "$gpu" "$dataset" "$seed" step_2500 2500
  run_sample "$gpu" "$dataset" "$seed" step_5000 5000
  run_sample "$gpu" "$dataset" "$seed" main 10000
  run_sample "$gpu" "$dataset" "$seed" step_20000 20000
  run_sample "$gpu" "$dataset" "$seed" time_no_condition 10000
}

pids=()
slot=0
for dataset in imdb pubmed; do
  for seed in "${RUN_SEEDS[@]}"; do
    echo "[WORKER] gpu=${GPUS[$slot]} dataset=$dataset seed=$seed"
    run_worker "${GPUS[$slot]}" "$dataset" "$seed" &
    pids+=("$!")
    slot=$((slot + 1))
  done
done
failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
[[ "$failed" -eq 0 ]] || { echo "one or more ablation workers failed" >&2; exit 1; }

python - "$OUT_ROOT" <<'PY'
import csv
import json
import pathlib
import statistics
import sys
from collections import defaultdict

root = pathlib.Path(sys.argv[1])
grouped = defaultdict(list)
for path in root.glob("*/seed*/*/gate_report.json"):
    dataset, mode = path.parts[-4], path.parts[-2]
    grouped[(dataset, mode)].append(json.loads(path.read_text())["final"])
for dataset in ("imdb", "pubmed"):
    grouped[(dataset, "calibration_strict")] = list(grouped[(dataset, "main")])
metrics = ("edges", "lcc", "triangles", "clustering", "assortativity",
           "sum_degree_sq", "max_degree")
rows = []
for (dataset, mode), values in sorted(grouped.items()):
    row = {"dataset": dataset, "mode": mode, "samples": len(values)}
    for metric in metrics:
        vector = [float(value[metric]) for value in values]
        row[f"{metric}_mean"] = statistics.fmean(vector)
        row[f"{metric}_std"] = statistics.pstdev(vector)
    rows.append(row)
out = root / "paper_tables" / "sample_ablation.tsv"
with out.open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
    writer.writeheader()
    writer.writerows(rows)
(root / "aggregate.json").write_text(json.dumps(rows, indent=2) + "\n")
print(f"[SUMMARY] {out}")
PY

echo "[CURRENT-BASE-DIFFUSION-ABLATION-DONE] $OUT_ROOT"
