from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Mapping, Sequence, Tuple

import numpy as np
import torch
from torch import nn

from .hgt_edit_denoiser import candidate_endpoint_matrix, graph_edge_tensors, graph_node_features
from .latent_edit_representation import RepresentationWarmupDataset, WarmupHGTEncoder
from .mixed_edit_diffusion import (
    EDIT_ACTIONS,
    align_mixed_edit_features_for_model,
    edit_distance_improvement,
    mixed_edit_candidate_matrix,
)
from .switch_diffusion import SwitchDenoiserMLP
from .role_guided_edit_diffusion import (
    sample_role_alignment_candidates,
    sample_switch_refinement_candidates,
)


@dataclass(frozen=True)
class CandidateTokenSnapshot:
    node_features: np.ndarray
    node_types: np.ndarray
    edge_index: np.ndarray
    edge_types: np.ndarray
    role_conditions: np.ndarray
    candidate_features: np.ndarray
    candidate_endpoints: np.ndarray
    candidate_improvements: np.ndarray
    time_fraction: float
    trajectory_id: int


@dataclass(frozen=True)
class CandidateTokenDataset:
    snapshots: Tuple[CandidateTokenSnapshot, ...]
    type_count: int
    family_count: int
    feature_profile: str


def _normalized_role_conditions(role_rows: np.ndarray, node_types: np.ndarray) -> np.ndarray:
    values = np.log1p(np.asarray(role_rows, dtype=np.float32))
    result = np.zeros_like(values)
    for type_id in np.unique(node_types).tolist():
        mask = np.asarray(node_types) == int(type_id)
        selected = values[mask]
        scale = np.maximum(selected.std(axis=0), 0.1)
        result[mask] = (selected - selected.mean(axis=0)) / scale
    return result


def build_candidate_token_dataset(
    dataset: RepresentationWarmupDataset,
    legacy: SwitchDenoiserMLP,
    *,
    feature_profile: str,
    candidates_per_example: int,
    candidate_sets_per_snapshot: int,
    seed: int,
    actions: Sequence[str] = EDIT_ACTIONS,
    inference_candidate_fraction: float = 0.8,
) -> CandidateTokenDataset:
    """Build utility supervision using the same proposal families as inference."""

    if int(candidates_per_example) < 2:
        raise ValueError("candidate-token training needs at least two candidates")
    if int(candidate_sets_per_snapshot) < 1:
        raise ValueError("candidate sets per snapshot must be positive")
    rows: List[CandidateTokenSnapshot] = []
    family_names = tuple(dataset.family_names)
    for snapshot_index, snapshot in enumerate(dataset.snapshots):
        feature_sets = []
        endpoint_sets = []
        improvement_sets = []
        role_map = {
            family: snapshot.role_rows[:, family_id]
            for family_id, family in enumerate(family_names)
        }
        for set_index in range(int(candidate_sets_per_snapshot)):
            rng = np.random.default_rng(
                int(seed) + 10_000_019 * snapshot_index + 97_409 * set_index
            )
            if set_index % 2 == 0:
                proposals = sample_role_alignment_candidates(
                    snapshot.graph,
                    snapshot.role_rows,
                    family_names,
                    rng,
                    int(candidates_per_example),
                    targeted_fraction=float(inference_candidate_fraction),
                    actions=tuple(
                        action for action in actions if action in {"relocation", "switch"}
                    ),
                )
            else:
                proposals = sample_switch_refinement_candidates(
                    snapshot.graph,
                    rng,
                    int(candidates_per_example),
                    closure_fraction=float(inference_candidate_fraction),
                )
            features = mixed_edit_candidate_matrix(
                snapshot.graph,
                proposals,
                snapshot.time_fraction,
                feature_profile=feature_profile,
                role_condition=role_map if feature_profile == "typed_closure_role_v3" else None,
            )
            feature_sets.append(
                align_mixed_edit_features_for_model(
                    features, legacy, family_count=dataset.family_count
                )
            )
            endpoint_sets.append(candidate_endpoint_matrix(proposals))
            improvement_sets.append(
                np.asarray(
                    [
                        edit_distance_improvement(snapshot.graph, snapshot.clean, proposal)
                        for proposal in proposals
                    ],
                    dtype=np.float32,
                )
            )
        edge_index, edge_types = graph_edge_tensors(snapshot.graph)
        rows.append(
            CandidateTokenSnapshot(
                node_features=graph_node_features(
                    snapshot.graph, snapshot.time_fraction
                ).astype(np.float32),
                node_types=dataset.node_types.copy(),
                edge_index=edge_index,
                edge_types=edge_types,
                role_conditions=_normalized_role_conditions(
                    snapshot.role_rows, dataset.node_types
                ),
                candidate_features=np.stack(feature_sets).astype(np.float32),
                candidate_endpoints=np.stack(endpoint_sets).astype(np.int64),
                candidate_improvements=np.stack(improvement_sets).astype(np.float32),
                time_fraction=float(snapshot.time_fraction),
                trajectory_id=int(snapshot.trajectory_id),
            )
        )
    return CandidateTokenDataset(
        snapshots=tuple(rows),
        type_count=dataset.type_count,
        family_count=dataset.family_count,
        feature_profile=str(feature_profile),
    )


class CandidateTokenEditResidual(nn.Module):
    """Jointly encode a complete edit while retaining the proven MLP score."""

    def __init__(
        self,
        representation: WarmupHGTEncoder,
        legacy: SwitchDenoiserMLP,
        *,
        token_dim: int = 64,
        heads: int = 4,
        token_layers: int = 1,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        if int(token_dim) % int(heads):
            raise ValueError("candidate token dimension must be divisible by heads")
        self.representation = representation
        self.legacy = legacy
        hidden_dim = int(representation.hidden_dim)
        self.operation_projection = nn.Sequential(
            nn.Linear(int(legacy.input_dim), int(token_dim)),
            nn.LayerNorm(int(token_dim)),
            nn.SiLU(),
        )
        self.endpoint_projection = nn.Sequential(
            nn.Linear(4 * hidden_dim, int(token_dim)),
            nn.LayerNorm(int(token_dim)),
            nn.SiLU(),
        )
        # Old-edge slots and new-edge slots share embeddings, making the
        # representation invariant to ordering within each pair of slots.
        self.slot_kind = nn.Embedding(2, int(token_dim))
        layer = nn.TransformerEncoderLayer(
            d_model=int(token_dim),
            nhead=int(heads),
            dim_feedforward=4 * int(token_dim),
            dropout=float(dropout),
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.token_encoder = nn.TransformerEncoder(layer, num_layers=int(token_layers))
        self.residual_head = nn.Sequential(
            nn.LayerNorm(int(token_dim)), nn.Linear(int(token_dim), 1)
        )
        final = self.residual_head[-1]
        assert isinstance(final, nn.Linear)
        nn.init.zeros_(final.weight)
        nn.init.zeros_(final.bias)
        self.config = {
            "token_dim": int(token_dim),
            "heads": int(heads),
            "token_layers": int(token_layers),
            "dropout": float(dropout),
        }

    def encode_graph(
        self,
        node_features: torch.Tensor,
        node_types: torch.Tensor,
        edge_index: torch.Tensor,
        edge_types: torch.Tensor,
        role_conditions: torch.Tensor,
    ) -> torch.Tensor:
        return self.representation.encode(
            node_features,
            node_types,
            edge_index,
            edge_types,
            role_conditions,
        )

    def encode_without_messages(
        self,
        node_features: torch.Tensor,
        role_conditions: torch.Tensor,
    ) -> torch.Tensor:
        """Retain local node/role inputs while removing graph propagation."""

        hidden = self.representation.node_input(node_features)
        if self.representation.role_input is not None:
            hidden = hidden + self.representation.role_input(role_conditions)
        return hidden

    def score_from_hidden(
        self,
        hidden: torch.Tensor,
        candidate_features: torch.Tensor,
        candidate_endpoints: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if candidate_features.ndim != 3 or candidate_endpoints.ndim != 3:
            raise ValueError("candidate-token inputs must have shape [B,C,*]")
        batch_size, candidate_count, _ = candidate_features.shape
        operation = self.operation_projection(candidate_features).reshape(
            batch_size * candidate_count, 1, -1
        )
        slot_tokens = []
        slot_valid = []
        for slot in range(4):
            u = candidate_endpoints[..., 2 * slot]
            v = candidate_endpoints[..., 2 * slot + 1]
            valid = (u >= 0) & (v >= 0)
            hu = hidden[u.clamp(min=0)]
            hv = hidden[v.clamp(min=0)]
            pair = torch.cat((hu, hv, torch.abs(hu - hv), hu * hv), dim=-1)
            kind = torch.full_like(u, 0 if slot < 2 else 1)
            token = self.endpoint_projection(pair) + self.slot_kind(kind)
            slot_tokens.append(token.reshape(batch_size * candidate_count, 1, -1))
            slot_valid.append(valid.reshape(batch_size * candidate_count, 1))
        tokens = torch.cat((operation, *slot_tokens), dim=1)
        valid = torch.cat(
            (
                torch.ones(
                    (batch_size * candidate_count, 1),
                    dtype=torch.bool,
                    device=tokens.device,
                ),
                *slot_valid,
            ),
            dim=1,
        )
        encoded = self.token_encoder(tokens, src_key_padding_mask=~valid)
        residual = self.residual_head(encoded[:, 0]).reshape(
            batch_size, candidate_count
        )
        base = self.legacy(candidate_features)
        return base + residual, base, residual

    def forward(
        self,
        node_features: torch.Tensor,
        node_types: torch.Tensor,
        edge_index: torch.Tensor,
        edge_types: torch.Tensor,
        role_conditions: torch.Tensor,
        candidate_features: torch.Tensor,
        candidate_endpoints: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        hidden = self.encode_graph(
            node_features, node_types, edge_index, edge_types, role_conditions
        )
        return self.score_from_hidden(hidden, candidate_features, candidate_endpoints)


class CandidateTokenResidualSampler(nn.Module):
    """Adapter exposing only the learned residual to the role-guided sampler."""

    def __init__(
        self,
        model: CandidateTokenEditResidual,
        feature_profile: str,
        *,
        role_phase_only: bool = False,
    ) -> None:
        super().__init__()
        self.model = model
        self.feature_profile = str(feature_profile)
        self.role_phase_only = bool(role_phase_only)

    def encode_graph(
        self,
        graph,
        time_fraction: float,
        device: torch.device,
        role_rows: np.ndarray,
    ) -> torch.Tensor:
        edge_index, edge_types = graph_edge_tensors(graph)
        return self.model.encode_graph(
            torch.from_numpy(graph_node_features(graph, time_fraction)).float().to(device),
            torch.from_numpy(graph.node_types).long().to(device),
            torch.from_numpy(edge_index).long().to(device),
            torch.from_numpy(edge_types).long().to(device),
            torch.from_numpy(
                _normalized_role_conditions(role_rows, graph.node_types)
            ).float().to(device),
        )

    def score_graph_candidates(
        self,
        graph,
        candidates,
        time_fraction: float,
        device: torch.device,
        encoded: torch.Tensor,
    ) -> torch.Tensor:
        if self.role_phase_only and all(
            proposal.action in {"noop", "switch"} for proposal in candidates
        ):
            return torch.zeros(len(candidates), dtype=torch.float32, device=device)
        features = mixed_edit_candidate_matrix(
            graph,
            candidates,
            time_fraction,
            feature_profile=self.feature_profile,
        )
        features = align_mixed_edit_features_for_model(
            features, self.model.legacy, family_count=len(graph.family_specs)
        )
        endpoints = candidate_endpoint_matrix(candidates)
        return self.model.score_from_hidden(
            encoded,
            torch.from_numpy(features)[None].float().to(device),
            torch.from_numpy(endpoints)[None].long().to(device),
        )[2].squeeze(0)


def load_alignment_encoder(
    checkpoint: str | Path,
    *,
    node_feature_dim: int,
    type_count: int,
    family_count: int,
) -> Tuple[WarmupHGTEncoder, Mapping[str, int]]:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if payload.get("format") != "dihug-role-conditioned-latent-alignment-v1":
        raise ValueError("unsupported latent-alignment checkpoint")
    state = payload["model_state"]
    hidden_dim = int(state["node_input.0.weight"].shape[0])
    role_dim = int(state["role_input.0.weight"].shape[1])
    layer_ids = {int(key.split(".")[1]) for key in state if key.startswith("layers.")}
    heads = int(state["layers.0.relation_pri"].shape[1])
    prototype_count = int(state["prototype_head.2.weight"].shape[0] // hidden_dim)
    if role_dim != int(family_count):
        raise ValueError("alignment role dimension does not match graph families")
    model = WarmupHGTEncoder(
        node_feature_dim=int(node_feature_dim),
        type_count=int(type_count),
        family_count=int(family_count),
        hidden_dim=hidden_dim,
        heads=heads,
        layers=len(layer_ids),
        dropout=0.0,
        role_condition_dim=role_dim,
        prototype_count=prototype_count,
    )
    model.load_state_dict(state, strict=True)
    return model, {
        "hidden_dim": hidden_dim,
        "heads": heads,
        "layers": len(layer_ids),
        "prototype_count": prototype_count,
    }


def _snapshot_tensors(
    snapshot: CandidateTokenSnapshot, device: torch.device
) -> Tuple[torch.Tensor, ...]:
    return (
        torch.from_numpy(snapshot.node_features).float().to(device),
        torch.from_numpy(snapshot.node_types).long().to(device),
        torch.from_numpy(snapshot.edge_index).long().to(device),
        torch.from_numpy(snapshot.edge_types).long().to(device),
        torch.from_numpy(snapshot.role_conditions).float().to(device),
        torch.from_numpy(snapshot.candidate_features).float().to(device),
        torch.from_numpy(snapshot.candidate_endpoints).long().to(device),
        torch.from_numpy(snapshot.candidate_improvements).float().to(device),
    )


def _set_trainable_legacy_last_layer(
    model: CandidateTokenEditResidual, enabled: bool
) -> None:
    for parameter in model.legacy.parameters():
        parameter.requires_grad_(False)
    if enabled:
        final = model.legacy.network[-1]
        if not isinstance(final, nn.Linear):
            raise TypeError("legacy scorer final layer must be linear")
        for parameter in final.parameters():
            parameter.requires_grad_(True)


def _utility_loss(
    logits: torch.Tensor,
    reference_logits: torch.Tensor,
    improvements: torch.Tensor,
    *,
    temperature: float,
    trust_weight: float,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    teacher = torch.softmax(improvements / float(temperature), dim=1)
    log_prob = torch.log_softmax(logits, dim=1)
    utility_ce = -(teacher * log_prob).sum(dim=1).mean()
    reference_prob = torch.softmax(reference_logits, dim=1)
    reference_log_prob = torch.log_softmax(reference_logits, dim=1)
    trust = (reference_prob * (reference_log_prob - log_prob)).sum(dim=1).mean()
    return utility_ce + float(trust_weight) * trust, utility_ce, trust


def evaluate_candidate_token_gate(
    dataset: CandidateTokenDataset,
    model: CandidateTokenEditResidual,
    reference: SwitchDenoiserMLP,
    *,
    device: str | torch.device,
) -> Mapping[str, object]:
    device = torch.device(device)
    model = model.to(device).eval()
    reference = reference.to(device).eval()
    validation_trajectory = max(row.trajectory_id for row in dataset.snapshots)
    aggregate: Dict[str, List[float]] = {}
    by_noise: Dict[str, Dict[str, List[float]]] = {}

    def append(store: Dict[str, List[float]], key: str, value: float) -> None:
        store.setdefault(key, []).append(float(value))

    with torch.no_grad():
        for snapshot in dataset.snapshots:
            if snapshot.trajectory_id != validation_trajectory:
                continue
            batch = _snapshot_tensors(snapshot, device)
            logits, _, residual = model(*batch[:-1])
            no_message_hidden = model.encode_without_messages(batch[0], batch[4])
            no_message_logits, _, _ = model.score_from_hidden(
                no_message_hidden, batch[5], batch[6]
            )
            reference_logits = reference(batch[5])
            utility = batch[-1]
            rows = torch.arange(logits.size(0), device=device)
            selected = logits.argmax(dim=1)
            baseline_selected = reference_logits.argmax(dim=1)
            oracle = utility.max(dim=1).values
            joint_utility = utility[rows, selected]
            baseline_utility = utility[rows, baseline_selected]
            joint_expected = (torch.softmax(logits, dim=1) * utility).sum(dim=1)
            baseline_expected = (
                torch.softmax(reference_logits, dim=1) * utility
            ).sum(dim=1)
            no_message_selected = no_message_logits.argmax(dim=1)
            no_message_utility = utility[rows, no_message_selected]
            no_message_expected = (
                torch.softmax(no_message_logits, dim=1) * utility
            ).sum(dim=1)
            level = f"{snapshot.time_fraction:.3f}"
            stores = (aggregate, by_noise.setdefault(level, {}))
            values = {
                "joint_selected_utility": joint_utility.mean().item(),
                "baseline_selected_utility": baseline_utility.mean().item(),
                "selected_utility_gain": (joint_utility - baseline_utility).mean().item(),
                "joint_expected_utility": joint_expected.mean().item(),
                "baseline_expected_utility": baseline_expected.mean().item(),
                "expected_utility_gain": (joint_expected - baseline_expected).mean().item(),
                "no_message_selected_utility": no_message_utility.mean().item(),
                "no_message_expected_utility": no_message_expected.mean().item(),
                "graph_context_selected_gain": (
                    joint_utility - no_message_utility
                ).mean().item(),
                "graph_context_expected_gain": (
                    joint_expected - no_message_expected
                ).mean().item(),
                "joint_regret": (oracle - joint_utility).mean().item(),
                "baseline_regret": (oracle - baseline_utility).mean().item(),
                "oracle_agreement": (selected == utility.argmax(dim=1)).float().mean().item(),
                "residual_std": residual.std().item(),
            }
            for store in stores:
                for key, value in values.items():
                    append(store, key, value)

    def reduce(values: Dict[str, List[float]]) -> Dict[str, float]:
        return {key: float(np.mean(items)) for key, items in values.items()}

    return {
        "validation_trajectory": int(validation_trajectory),
        "overall": reduce(aggregate),
        "by_noise": {key: reduce(values) for key, values in by_noise.items()},
    }


def train_candidate_token_gate(
    dataset: CandidateTokenDataset,
    representation: WarmupHGTEncoder,
    legacy: SwitchDenoiserMLP,
    *,
    phase1_epochs: int = 8,
    phase2_epochs: int = 4,
    learning_rate: float = 2.0e-4,
    legacy_last_layer_lr: float = 1.0e-5,
    weight_decay: float = 1.0e-4,
    utility_temperature: float = 0.5,
    trust_weight: float = 0.25,
    device: str | torch.device = "cuda",
    seed: int = 0,
    **model_kwargs,
) -> Tuple[CandidateTokenEditResidual, Mapping[str, object]]:
    torch.manual_seed(int(seed))
    rng = np.random.default_rng(int(seed))
    device = torch.device(device)
    model = CandidateTokenEditResidual(
        representation, copy.deepcopy(legacy), **model_kwargs
    ).to(device)
    reference = copy.deepcopy(legacy).to(device).eval()
    for parameter in reference.parameters():
        parameter.requires_grad_(False)
    validation_trajectory = max(row.trajectory_id for row in dataset.snapshots)
    train_rows = [
        row for row in dataset.snapshots if row.trajectory_id != validation_trajectory
    ]
    history = []

    for phase, epochs in (("residual", int(phase1_epochs)), ("joint_last", int(phase2_epochs))):
        if epochs <= 0:
            continue
        joint_last = phase == "joint_last"
        _set_trainable_legacy_last_layer(model, joint_last)
        residual_parameters = [
            parameter
            for name, parameter in model.named_parameters()
            if parameter.requires_grad and not name.startswith("legacy.")
        ]
        groups = [{"params": residual_parameters, "lr": float(learning_rate)}]
        if joint_last:
            groups.append(
                {
                    "params": [
                        parameter
                        for parameter in model.legacy.network[-1].parameters()
                        if parameter.requires_grad
                    ],
                    "lr": float(legacy_last_layer_lr),
                }
            )
        optimizer = torch.optim.AdamW(groups, weight_decay=float(weight_decay))
        for epoch in range(epochs):
            model.train()
            # Keep dropout in the legacy trunk disabled; only its final affine
            # layer is adapted in phase two.
            model.legacy.eval()
            losses = []
            utility_losses = []
            trust_losses = []
            residual_stds = []
            for row_index in rng.permutation(len(train_rows)).tolist():
                batch = _snapshot_tensors(train_rows[int(row_index)], device)
                optimizer.zero_grad(set_to_none=True)
                logits, _, residual = model(*batch[:-1])
                with torch.no_grad():
                    reference_logits = reference(batch[5])
                loss, utility_loss, trust = _utility_loss(
                    logits,
                    reference_logits,
                    batch[-1],
                    temperature=float(utility_temperature),
                    trust_weight=float(trust_weight),
                )
                loss.backward()
                nn.utils.clip_grad_norm_(
                    [parameter for group in groups for parameter in group["params"]], 5.0
                )
                optimizer.step()
                losses.append(float(loss.detach().cpu()))
                utility_losses.append(float(utility_loss.detach().cpu()))
                trust_losses.append(float(trust.detach().cpu()))
                residual_stds.append(float(residual.detach().std().cpu()))
            record = {
                "phase": phase,
                "epoch": int(epoch),
                "loss": float(np.mean(losses)),
                "utility_loss": float(np.mean(utility_losses)),
                "trust_kl": float(np.mean(trust_losses)),
                "residual_std": float(np.mean(residual_stds)),
            }
            history.append(record)
            print(
                "[CANDIDATE-TOKEN-EPOCH] "
                + " ".join(f"{key}={value}" for key, value in record.items()),
                flush=True,
            )
    evaluation = evaluate_candidate_token_gate(
        dataset, model, reference, device=device
    )
    return model, {
        "history": history,
        "evaluation": evaluation,
        "phase1_epochs": int(phase1_epochs),
        "phase2_epochs": int(phase2_epochs),
        "utility_temperature": float(utility_temperature),
        "trust_weight": float(trust_weight),
        "joint_last_layer": int(phase2_epochs) > 0,
    }
